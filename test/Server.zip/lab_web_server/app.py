# -*- coding: utf-8 -*-
"""
  Project: Flask WebServer Robust Industrial AP Receiver – Version 3.7 (Live Data Fix)
  Feature: Correct LATEST Data Retrieval, Strict Timestamp Sorting
  Engineer: [Peyman parsa] - Electronic Perspective
  
  Critical Fix:
  - Fixed '/api/sensor_data' to fetch the NEWEST 50 records (DESC sort -> Limit -> Reverse).
  - Ensured Dashboard always shows the absolute latest packet.
"""

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, Response
from flask_sqlalchemy import SQLAlchemy
import datetime 
import io
import csv 
import pytz 
import serial
import threading
import time
import serial.tools.list_ports 
import os
import sqlite3

app = Flask(__name__)
app.config['SECRET_KEY'] = 'industrial_secret_key_v3_7_live_fix' 

# --- تنظیمات زمانی و دیتابیس جامع ---
TEHRAN_TZ = pytz.timezone('Asia/Tehran')
MASTER_DB_URI = 'sqlite:///master_industrial.db'

app.config['SQLALCHEMY_DATABASE_URI'] = MASTER_DB_URI
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False 

db = SQLAlchemy(app)

# --- مدل‌های داده ---
class MasterReading(db.Model):
    id = db.Column(db.Integer, primary_key=True) 
    num_value = db.Column(db.Integer, nullable=True, index=True) 
    nbcm_selected = db.Column(db.String(100), nullable=True) 
    humidity = db.Column(db.String(50), nullable=True)
    temp = db.Column(db.String(50), nullable=True)
    time = db.Column(db.String(50), nullable=True) 
    date = db.Column(db.String(50), nullable=True) 
    timestamp = db.Column(db.DateTime, nullable=False, index=True) 
    formatted_log = db.Column(db.String(500), nullable=True)
    
class DailyRecordAdapter:
    def __init__(self, row):
        # row ساختاری است که از کوئری SELECT برمی‌گردد
        self.id = row[0]
        self.num_value = row[1]
        self.nbcm_selected = row[2] if row[2] else ""  # هندل کردن null
        self.temp = row[3]
        self.humidity = row[4]
        self.date = row[6] 
        self.time = row[7]
        # تبدیل رشته‌ی زمان ذخیره شده به آبجکت datetime
        # این کار ضروری است چون در HTML از متد .strftime() استفاده شده است
        time_str = row[5]
        try:
            # تلاش برای پارس کردن فرمت استاندارد (همراه با میکروثانیه)
            self.timestamp = datetime.datetime.strptime(time_str, '%Y-%m-%d %H:%M:%S.%f%z')
        except:
            try:
                # تلاش دوم: بدون تایم‌زون یا فرمت ساده‌تر
                self.timestamp = datetime.datetime.strptime(time_str.split('+')[0], '%Y-%m-%d %H:%M:%S.%f')
            except:
                try:
                     # تلاش سوم: فرمت ثانیه‌ای بدون اعشار
                     self.timestamp = datetime.datetime.strptime(time_str.split('.')[0], '%Y-%m-%d %H:%M:%S')
                except:
                     # در صورت خطا، زمان فعلی جایگزین می‌شود تا برنامه کرش نکند
                     self.timestamp = datetime.datetime.now()
                

# --- توابع مدیریت دیتابیس ---
def get_daily_db_path(date_str=None):
    if not date_str:
        date_str = datetime.datetime.now(TEHRAN_TZ).strftime('%Y-%m-%d')
    return f"{date_str}.db"

def cleanup_old_databases(days_to_keep=7):
    now = datetime.datetime.now(TEHRAN_TZ)
    for filename in os.listdir('.'):
        if filename.endswith('.db') and filename != 'master_industrial.db':
            try:
                date_part = filename.replace('.db', '')
                file_date = datetime.datetime.strptime(date_part, '%Y-%m-%d')
                file_date = TEHRAN_TZ.localize(file_date)
                if (now - file_date).days >= days_to_keep:
                    os.remove(filename)
            except:
                continue

def get_available_dates():
    try:
        with app.app_context():
            # سورت DESC بسیار مهم است
            dates = db.session.query(MasterReading.date).distinct().order_by(MasterReading.date.desc()).all()
            return [d[0] for d in dates if d[0]]
    except Exception as e:
        print(f"[DB Error] {e}")
        return []

# --- توابع نرمال‌سازی ---
def normalize_value(val, min_v, max_v, default):
    try:
        if val is None: return str(default)
        # اصلاحیه: اضافه شدن c == '-' برای پشتیبانی از اعداد منفی
        clean_val = "".join(c for c in str(val) if c.isdigit() or c == '.' or c == '-')
        
        # هندل کردن حالت‌هایی مثل "--5" یا "-" خالی
        if not clean_val or clean_val == '-': return str(default)
            
        f_val = float(clean_val)
        f_val = max(min_v, min(max_v, f_val))
        return str(round(f_val, 1))
    except: return str(default)

def safe_int(val, default=0):
    try:
        if val is None: return default
        numeric_filter = "".join(filter(str.isdigit, str(val).strip()))
        return int(numeric_filter) if numeric_filter else default
    except: return default

def save_sensor_data(data_source):
    try:
        # پاکسازی فایل‌های خیلی قدیمی طبق روتین قبل
        cleanup_old_databases()
        
        # --- استخراج و پردازش داده‌ها (مشترک) ---
        if hasattr(data_source, 'getlist'): 
            nbcm_checked_list = data_source.getlist('nbcm')
            num_val_raw = data_source.get('num_value')
        else: 
            nbcm_checked_list = data_source.get('nbcm', []) 
            num_val_raw = data_source.get('num_value') 

        num_int = safe_int(num_val_raw)
        h_val = normalize_value(data_source.get('humidity'), -100, 100, 0)
        t_val = normalize_value(data_source.get('temp'), -100, 155, 0)
        
        now_tehran = datetime.datetime.now(TEHRAN_TZ)
        # اولویت با زمان ارسالی سنسور است، اگر نبود زمان سرور
        i_time = data_source.get('time') or now_tehran.strftime('%H:%M:%S')
        i_date = data_source.get('date') or now_tehran.strftime('%Y-%m-%d')
        nbcm_str = ",".join(nbcm_checked_list)
        log_str = f"NUM:{num_int}, H:{h_val}, T:{t_val}"

        # ---------------------------------------------------------
        # 1. ذخیره در دیتابیس اصلی (Master DB) - طبق روال قبل
        # ---------------------------------------------------------
        master_entry = MasterReading(
            num_value=num_int, nbcm_selected=nbcm_str,
            humidity=h_val, temp=t_val, time=i_time, date=i_date,
            timestamp=now_tehran, formatted_log=log_str
        )
        db.session.add(master_entry)
        db.session.commit()

        # ---------------------------------------------------------
        # 2. ذخیره در دیتابیس روزانه (Daily DB) - بخش جدید
        # ---------------------------------------------------------
        daily_db_path = f"{i_date}.db" # نام فایل بر اساس تاریخ روز: 2026-01-01.db
        
        # استفاده از context manager برای بستن خودکار کانکشن
        with sqlite3.connect(daily_db_path) as conn:
            c = conn.cursor()
            
            # ایجاد جدول اگر وجود نداشته باشد
            c.execute('''CREATE TABLE IF NOT EXISTS daily_records (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        num_value INTEGER,
                        nbcm_selected TEXT,
                        temp TEXT,
                        humidity TEXT,
                        log_date TEXT,
                        log_time TEXT,
                        full_timestamp DATETIME
                    )''')

            # *** نکته مهم مهندسی (SORTING) ***
            # ایجاد ایندکس ترکیبی روی تاریخ و ساعت.
            # این دستور باعث می‌شود داده‌ها هنگام خواندن بدون نیاز به پردازش اضافه،
            # کاملاً سورت شده (اول تاریخ، بعد ساعت) باشند.
            c.execute("CREATE INDEX IF NOT EXISTS idx_date_time ON daily_records (log_date, log_time)")

            # تزریق داده
            c.execute('''INSERT INTO daily_records 
                        (num_value, nbcm_selected, temp, humidity, log_date, log_time, full_timestamp)
                        VALUES (?, ?, ?, ?, ?, ?, ?)''',
                        (num_int, nbcm_str, t_val, h_val, i_date, i_time, now_tehran))
            
            conn.commit()

        return True

    except Exception as e:
        db.session.rollback() # رول‌بک فقط برای مستر نیاز است
        print(f"[CRITICAL_DB_ERROR] {e}")
        return False

# --- مدیریت سریال ---
ser = None 
serial_thread = None
stop_event = threading.Event()
active_serial_port = None 
active_baud_rate = 115200 
DEFAULT_PORT = "COM9"
manual_disconnect = False

def parse_industrial_line(line):
    try:
        if "NUM=" in line:
            clean_line = line[line.find("NUM="):]
            parts = {p.split('=')[0].strip(): p.split('=')[1].strip() for p in clean_line.split(',') if '=' in p}
            return {
                'num_value': parts.get('NUM'),
                'nbcm': [f'NBCM{i}' for i in range(1, 5) if parts.get(f'NBCM{i}') == 'OK'],
                'temp': parts.get('Temp', '0'),
                'humidity': parts.get('Humidity', '0'),
                'date': parts.get('Date', 'N/A'),
                'time': parts.get('Time', 'N/A')
            }
    except: return None

def read_serial_worker():
    global ser, active_serial_port, manual_disconnect
    
    while not stop_event.is_set():
        try:
            if (ser is None or not ser.is_open) and not manual_disconnect:
                available = [p.device.upper() for p in serial.tools.list_ports.comports()]
                target_port = active_serial_port if active_serial_port else (DEFAULT_PORT if DEFAULT_PORT in available else None)
                
                if target_port and target_port in available:
                    active_serial_port = target_port
                    try:
                        ser = serial.Serial(active_serial_port, active_baud_rate, timeout=1)
                        print(f"[SERIAL] Connected to {active_serial_port}")
                    except Exception as e:
                        print(f"[SERIAL_ERR] {e}")
                        time.sleep(2)
                else:
                    time.sleep(5)
                    continue

            if ser and ser.is_open and ser.in_waiting > 0:
                try:
                    raw = ser.readline().decode('utf-8', errors='ignore').strip()
                    if not raw: continue
                    print(f"[RX_RAW] {raw}")
                    if "NUM=" in raw: 
                        payload = parse_industrial_line(raw)
                        if payload:
                            with app.app_context(): save_sensor_data(payload)
                except Exception as read_err:
                    print(f"[READ_ERR] {read_err}")
            time.sleep(0.01)

        except Exception as e:
            if ser: 
                try: ser.close() 
                except: pass
            ser = None
            time.sleep(10)

# --- Routes ---

@app.route('/')
def home():
    # اطمینان از اینکه در لود اولیه صفحه، حتما آخرین رکورد ارسال شود
    last = MasterReading.query.order_by(MasterReading.timestamp.desc()).first()
    return render_template('index.html', last_data=last)

@app.route('/history')
def history():
    target_date = request.args.get('date')
    readings = []
    label = "آرشیو کامل (Master DB)"
    
    # لیست تاریخ‌های موجود را همچنان از مستر می‌گیریم (چون مرجع جامع است)
    available_dates = get_available_dates()

    if target_date:
        # سناریوی صنعتی: خواندن از فایل روزانه (Distributed Data Access)
        daily_db_path = f"{target_date}.db"
        
        if os.path.exists(daily_db_path):
            try:
                label = f"آرشیو روزانه (Source: {target_date}.db)"
                
                # اتصال به دیتابیس روزانه
                with sqlite3.connect(daily_db_path) as conn:
                    c = conn.cursor()
                    
                    # دریافت داده‌ها با استفاده از ایندکس زمانی که قبلاً ساختیم
                    # ترتیب نزولی (DESC) یعنی جدیدترین داده‌ها اول نمایش داده شوند
                    c.execute("""
                        SELECT id, num_value, nbcm_selected, temp, humidity, full_timestamp 
                        FROM daily_records 
                        ORDER BY log_date DESC, log_time DESC
                    """)
                    
                    rows = c.fetchall()
                    
                    # تبدیل داده‌های خام به آبجکت‌های سازگار با HTML
                    readings = [DailyRecordAdapter(row) for row in rows]
                    
            except Exception as e:
                flash(f"خطا در بارگذاری فایل روزانه: {e}", "danger")
                readings = []
        else:
            # حالت Fallback: اگر فایل روزانه نبود، از مستر بخوان
            # (مثلاً برای داده‌های قدیمی که قبل از این آپدیت ثبت شده‌اند)
            label = f"آرشیو فیلتر شده (Master DB): {target_date}"
            query = MasterReading.query.filter(MasterReading.date == target_date)
            readings = query.order_by(MasterReading.timestamp.desc()).all()
            
    else:
        # حالت پیش‌فرض: نمایش تمام داده‌ها از مستر
        readings = MasterReading.query.order_by(MasterReading.timestamp.desc()).all()

    return render_template('history.html', readings=readings, label=label, dates=available_dates, current_date=target_date)

@app.route('/submit_form', methods=['POST'])
def submit_form():
    if save_sensor_data(request.form):
        flash("اطلاعات ثبت شد.", "success")
    else:
        flash("خطا در ثبت.", "danger")
    return redirect(url_for('home'))

@app.route('/api/sensor_data')
def get_sensor_data():
    """
    API داشبورد زنده:
    اصلاحیه مهم: ابتدا نزولی مرتب می‌کنیم تا جدیدترین‌ها را بگیریم،
    سپس لیست را معکوس می‌کنیم تا در نمودار/داشبورد روند درستی داشته باشد.
    """
    # گام 1: دریافت 50 رکورد آخر (جدیدترین‌ها)
    readings = MasterReading.query.order_by(MasterReading.timestamp.desc()).limit(50).all()
    
    # گام 2: معکوس کردن لیست برای نمایش کرونولوژیک (قدیمی‌ترینِ این دسته -> جدیدترینِ این دسته)
    # این کار باعث می‌شود عنصر آخر آرایه (length-1) همیشه "جدیدترین" داده باشد.
    readings = readings[::-1]
    
    output = []
    for r in readings:
        nbcm_map = {f"NBCM{i}": ("active" if f"NBCM{i}" in (r.nbcm_selected or "") else "notactive") for i in range(1, 5)}
        output.append({
            'num_value': r.num_value, 'temp': r.temp, 'humidity': r.humidity,
            'time': r.time, 'date': r.date, 'timestamp': r.timestamp,
            'nbcm_statuses': nbcm_map
        })
    return jsonify(output)

@app.route('/api/master_data')
def get_master_data():
    """
    API نمودار هوشمند:
    - اگر فیلتر تاریخ داشت: طبق فیلتر عمل می‌کند.
    - اگر فیلتر نداشت (حالت پیش‌فرض): آخرین روزی که در دیتابیس دیتا دارد را پیدا کرده
      و فقط داده‌های همان روز را برمی‌گرداند.
    """
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    query = MasterReading.query
    
    # سناریوی ۱: کاربر بازه زمانی انتخاب کرده است
    if start_date or end_date:
        if start_date:
            try:
                s_date = datetime.datetime.strptime(start_date, '%Y-%m-%d')
                query = query.filter(MasterReading.timestamp >= s_date)
            except ValueError: pass

        if end_date:
            try:
                e_date = datetime.datetime.strptime(end_date, '%Y-%m-%d')
                # برای شامل شدن کامل روز پایان، یک روز به آن اضافه می‌کنیم
                e_date = e_date + datetime.timedelta(days=1)
                query = query.filter(MasterReading.timestamp < e_date)
            except ValueError: pass
            
    # سناریوی ۲ (جدید): هیچ تاریخی انتخاب نشده (حالت پیش‌فرض لود صفحه)
    else:
        # پیدا کردن جدیدترین رکورد ثبت شده برای استخراج تاریخ آن
        last_record = MasterReading.query.order_by(MasterReading.timestamp.desc()).first()
        if last_record:
            # فیلتر کردن کوئری فقط روی همان روز خاص
            target_date = last_record.date
            query = query.filter(MasterReading.date == target_date)
        else:
            # دیتابیس کلاً خالی است
            return jsonify([])

    # مرتب‌سازی صعودی برای نمایش صحیح در نمودار (از صبح به شب)
    readings = query.order_by(MasterReading.timestamp.asc()).all()
    
    output = []
    for r in readings:
        nbcm_map = {f"NBCM{i}": ("active" if f"NBCM{i}" in (r.nbcm_selected or "") else "notactive") for i in range(1, 5)}
        output.append({
            'num_value': r.num_value, 'temp': r.temp, 'humidity': r.humidity,
            'timestamp': r.timestamp.isoformat(), 
            'nbcm_statuses': nbcm_map,
            'date': r.date
        })

    return jsonify(output)

@app.route('/api/serial_ports')
def list_serial_ports():
    ports = [port.device for port in serial.tools.list_ports.comports()]
    return jsonify({'available_ports': ports, 'active_port': active_serial_port, 'connection_status': 'Connected' if (ser and ser.is_open) else 'Disconnected'})

@app.route('/api/set_serial_config', methods=['POST'])
def set_serial_config():
    global active_serial_port, active_baud_rate, serial_thread, manual_disconnect
    data = request.get_json()
    stop_event.set()
    if ser: ser.close()
    if serial_thread: serial_thread.join(timeout=2)
    active_serial_port = data.get('port')
    active_baud_rate = data.get('baud_rate', 115200)
    manual_disconnect = False
    stop_event.clear()
    serial_thread = threading.Thread(target=read_serial_worker, daemon=True)
    serial_thread.start()
    return jsonify({'status': 'success', 'port': active_serial_port})

@app.route('/api/close_serial_port', methods=['POST'])
def close_serial_port():
    global ser, active_serial_port, manual_disconnect
    try:
        manual_disconnect = True
        if ser and ser.is_open: ser.close()
        active_serial_port = None
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/export_excel')
def export_excel():
    target_date = request.args.get('date')
    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerow(['ID', 'NUM', 'NBCM', 'Temp', 'Humidity', 'Time', 'Date', 'Timestamp'])
    
    query = MasterReading.query
    if target_date:
        query = query.filter(MasterReading.date == target_date)
    recs = query.order_by(MasterReading.timestamp.desc()).all()
    
    for r in recs:
        cw.writerow([r.id, r.num_value, r.nbcm_selected, r.temp, r.humidity, r.time, r.date, r.timestamp])
    
    return Response(si.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename=report.csv"})

@app.route('/clear_history', methods=['POST'])
def clear_history():
    target_date = request.args.get('date')
    try:
        if target_date:
            MasterReading.query.filter(MasterReading.date == target_date).delete()
            flash(f"داده‌های تاریخ {target_date} حذف شد.", "info")
        else:
            MasterReading.query.delete()
            flash("کل دیتابیس پاکسازی شد.", "warning")
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        flash(f"خطا: {e}", "danger")
    return redirect(url_for('history', date=target_date))

@app.route('/plot_display')
def plot_display():
    return render_template('plot_display.html')

if __name__ == '__main__':
    with app.app_context():
        db.create_all() 
    
    stop_event.clear()
    serial_thread = threading.Thread(target=read_serial_worker, daemon=True)
    serial_thread.start()
    
    app.run(debug=True, port=5000, use_reloader=False)